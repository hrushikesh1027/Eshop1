from django.contrib import admin
from store.models import *
# Register your models here.



class SizeVarientConfiguration(admin.TabularInline):
    model = SizeVarient

class ProductConfiguration(admin.ModelAdmin):
    inlines = [SizeVarientConfiguration]
    list_display = ['name','slug']


admin.site.register(Product,ProductConfiguration)
admin.site.register(Brand)
admin.site.register(Color)
admin.site.register(Category)
admin.site.register(NeckType)
admin.site.register(Occasion)
admin.site.register(Sleeve)
admin.site.register(Cart)
admin.site.register(Payment)
admin.site.register(Order)
admin.site.register(OrderItem)
