from django.db import models
from django.contrib.auth.models import User
# Create your models here.


class TshirtProperty(models.Model):
    title = models.CharField(max_length=30, null=False)
    slug = models.CharField(max_length=30, null=False,unique=True)

    def __str__(self):
        return self.title

    class Meta :
        abstract = True


class Occasion(TshirtProperty):
    pass

class Category(TshirtProperty):
   pass

class NeckType(TshirtProperty):
    pass

class Sleeve(TshirtProperty):
    pass

class Brand(TshirtProperty):
    pass

class Color(TshirtProperty):
    pass

class Product(models.Model):
    name = models.CharField(max_length=50,null=False)
    slug = models.CharField(max_length=200,null=True,unique=True,default="")
    discription = models.CharField(max_length=500,null=True)
    discount = models.IntegerField(default=0)
    image = models.ImageField(upload_to = 'upload/images/',null=False)
    category = models.ForeignKey(Category, on_delete=models.CASCADE, null=True, blank=True)
    occasion = models.ForeignKey(Occasion,on_delete=models.CASCADE,null=True,blank=True)
    brand = models.ForeignKey(Brand,on_delete=models.CASCADE,null=True,blank=True)
    sleeve = models.ForeignKey(Sleeve,on_delete=models.CASCADE,null=True,blank=True)
    neck_type = models.ForeignKey(NeckType,on_delete=models.CASCADE,null=True,blank=True)
    color = models.ForeignKey(Color,on_delete=models.CASCADE,null=True,blank=True)

    def __str__(self):
        return self.name

class SizeVarient(models.Model):
    SIZES = (
        ('S' , "Small"),
        ('M' , "Medium"),
        ('L' , "Large"),
        ('XL' , "Extra Large"),
        ('XXl' , "Extra Extra Large"),

    )
    price = models.IntegerField(null=False)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    size = models.CharField(choices=SIZES,max_length=5)



class Cart(models.Model):
    sizeVariant = models.ForeignKey(SizeVarient , on_delete = models.CASCADE)
    quantity= models.IntegerField(default=1)
    user = models.ForeignKey(User , on_delete = models.CASCADE)


class Order(models.Model):
    orderStatus = (
        ('PENDING', "Pending"),
        ('PLACED', "Placed"),
        ('CANCELED', "Canceled"),
        ('COMPLETED', "Completed"),
    )
    method = (

        ('ONLINE', "Online"),
    )
    order_status = models.CharField(max_length=15, choices=orderStatus)
    payment_method = models.CharField(max_length=15, choices=method)
    shipping_address = models.CharField(max_length=100, null=False)
    phone = models.CharField(max_length=10, null=False)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    total = models.IntegerField(null=False)
    date = models.DateTimeField(null=False, auto_now_add=True)


class OrderItem(models.Model):
    order = models.ForeignKey(Order , on_delete = models.CASCADE)
    product = models.ForeignKey(Product , on_delete = models.CASCADE)
    size = models.ForeignKey(SizeVarient , on_delete = models.CASCADE)
    quantity = models.IntegerField(null=False)
    price = models.IntegerField(null=False)
    date = models.DateTimeField(null= False , auto_now_add=True)


class Payment(models.Model):
    order = models.ForeignKey(Order , on_delete = models.CASCADE)
    date = models.DateTimeField(null= False , auto_now_add=True)
    payment_status = models.CharField(max_length=15 , default='FAILED')
    payment_id = models.CharField(max_length=60)
    payment_request_id = models.CharField(max_length=60 , unique=True , null=False)