from django.contrib import admin
from django.urls import path
from store.views import *

urlpatterns = [
    path('',home,name='homepage'),
    path('cart/',cart),
    path('orders/',orders , name = 'orders'),
    path('login/',login,name='login'),
    path('signup/',signup),
    path('logout/',signout),
    path('checkout/',checkout),
    path('validate_payment',validatePayment),
    path('item/<str:slug>',show_item),
    path('addtocart/<str:slug>/<str:size>',addtocart)
]